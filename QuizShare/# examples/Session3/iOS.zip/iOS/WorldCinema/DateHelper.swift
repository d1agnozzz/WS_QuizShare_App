//
//  DateHelper.swift
//  WorldCinema
//
//  Copyright © 2020 WS. All rights reserved.
//

import Foundation

class DateHelper {
    //TODO: пригодится для реализации чата
    
    static func getDateForChat(dateString: String) -> String {
      
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        if let date = formatter.date(from: dateString) {
            let calendar = Calendar.current
            if calendar.isDateInToday(date) {
                return "Сегодня"
            } else {
                return dateString
            }
        }
        
        return dateString
    }
}
