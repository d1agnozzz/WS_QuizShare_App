//
//  ImageHelper.swift
//  WorldCinema
//
//  Copyright © 2020 WS. All rights reserved.
//

import Foundation

class ImageHelper {
    static func getImagePath(localPath: String?) -> String {
        return "http://cinema.areas.su/up/images/\(localPath!)
    }
}
