//
//  Message.swift
//  WorldCinema
//
//  Copyright © 2020 WS. All rights reserved.
//

import Foundation

class Message: Decodable {
    var messageId = 0
    var creationDateTime: String? = nil
    var authorName: String? = nil
    var authorAvatarId: String? = nil
    var text: String? = nil
}
