//
//  Cover.swift
//  WorldCinema
//
//  Copyright © 2020 WS. All rights reserved.
//

import Foundation

class Cover: Decodable {
    var movieId: String? = nil
    var backgroundImage: String? = nil
    var foregroundImage: String? = nil
}
