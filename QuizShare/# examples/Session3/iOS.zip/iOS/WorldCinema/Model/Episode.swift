//
//  Episode.swift
//  WorldCinema
//
//  Copyright © 2020 WS. All rights reserved.
//

import Foundation

class Episode: Decodable {
    var episodeId: String? = nil
    var name: String? = nil
    var description: String? = nil
    var director: String? = nil
    var year: String? = nil
    var stars: [String]? = nil
    var runtime: String? = nil
    var preview: String? = nil
    var images: [String] = []
}
