//
//  Movie.swift
//  WorldCinema
//
//  Copyright © 2020 WS. All rights reserved.
//

import Foundation
import UIKit

class Movie: Decodable {
    var movieId : String? = nil
    var name: String? = nil
    var description: String? = nil
    var age: String? = nil
    var images: [String]? = nil
    var poster: String? = nil

    func getAgeInFormat() -> String {
        return "\(age!)+"
    }

    var ageColor: UIColor {
        get {
            
            switch (age) {
            case "0":
                return .white
                
                case "6":
                    return UIColor.init(red: 250.0/255, green: 243/255.0, blue: 201/255.0, alpha: 1)
                
                case "12":
                    return UIColor.init(red: 244.0/255, green: 169/255.0, blue: 146/255.0, alpha: 1)
                
                case "16":
                    return UIColor.init(red: 242.0/255, green: 110/255.0, blue: 69/255.0, alpha: 1)
                
                case "18":
                    return UIColor.init(red: 239.0/255, green: 58/255.0, blue: 1/255.0, alpha: 1)
                
            default:
                return .white
        }
    }
}
}
