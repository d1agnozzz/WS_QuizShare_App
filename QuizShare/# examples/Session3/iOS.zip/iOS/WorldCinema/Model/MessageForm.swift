//
//  MessageForm.swift
//  WorldCinema
//
//  Copyright © 2020 WS. All rights reserved.
//

import Foundation

class MessageForm: Encodable {
    var text: String? = nil

}
