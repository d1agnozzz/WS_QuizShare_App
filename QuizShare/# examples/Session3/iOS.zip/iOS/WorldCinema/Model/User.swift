//
//  User.swift
//  WorldCinema
//
//  Copyright © 2020 WS. All rights reserved.
//

import Foundation

class User: Decodable {
    var userId: String? = nil
    var firstName: String? = nil
    var lastName: String? = nil
    var email: String? = nil
    var avatarId: String? = nil

}
