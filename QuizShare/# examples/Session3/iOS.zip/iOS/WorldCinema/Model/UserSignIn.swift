//
//  UserSignIn.swift
//  WorldCinema
//
//  Copyright © 2020 WS. All rights reserved.
//

import Foundation
class UserSignIn: Encodable {
    var email = ""
    var password = ""
}
