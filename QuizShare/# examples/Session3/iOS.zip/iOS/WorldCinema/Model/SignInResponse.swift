//
//  SignInResponse.swift
//  WorldCinema
//
//  Copyright © 2020 WS. All rights reserved.
//

import Foundation

class SignInResponse: Decodable {
    var token: Int? = nil

}
