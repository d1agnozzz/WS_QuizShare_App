//
//  Chat.swift
//  WorldCinema
//
//  Copyright © 2020 WS. All rights reserved.
//

import Foundation

public class Chat: Decodable {
    
    var chatId = 0
    var movieName: String? = nil
    var movieId  = 0
}
