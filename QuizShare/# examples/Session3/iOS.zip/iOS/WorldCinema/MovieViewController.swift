//
//  MovieViewController.swift
//  WorldCinema
//
//  Created by WorldSkills MAD.
//  Copyright © 2020 WS. All rights reserved.
//

import UIKit

class MovieViewController: UIViewController,  UICollectionViewDataSource, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var movieDescriptionLabel: UILabel!
    @IBOutlet weak var episodesTableView: UITableView!
    @IBOutlet weak var framesCollectionView: UICollectionView!
    
    
    var movieId: String? = nil
    private var movie: Movie? = nil
    private var episodes: [Episode]? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        framesCollectionView.dataSource = self
        episodesTableView.register(UINib(nibName: "EpisodeTableViewCell", bundle: nil), forCellReuseIdentifier: "episodeCell")
        episodesTableView.rowHeight = UITableView.automaticDimension
        episodesTableView.estimatedRowHeight = 153.0;
        
        if movieId == nil {
            DialogManager.showErrorDialog(controller: self, title: "Ошибка", message: "Фильм не найден")
        } else {
            requestMovie(movieId: movieId!)
        }
    }
    
    private func requestMovie(movieId: String) {
        let service = AlamofireSingleton()
        service.getMovie(movieId: movieId, { [weak self] (movie) in
            self?.setupScreen(movie: movie!)
            self?.requestEpisodes(movieId: movieId)
        }) { (error) in
            DialogManager.showErrorDialog(controller: self, title: "Ошибка от сервера", message: error)
        }
    }
    
    private func setupScreen(movie: Movie) {
        self.movie = movie
        title = movie.name
        posterImageView.kf.setImage(with: URL(string: ImageHelper.getImagePath(localPath: movie.poster)));
        movieDescriptionLabel.text = movie.description!
        ageLabel.text = movie.getAgeInFormat()
        ageLabel.textColor = movie.ageColor
        framesCollectionView.reloadData()
    }
    
    private func requestEpisodes(movieId: String) {
        let service = AlamofireSingleton()
        service.getMoviesEpisodes(movieId: movieId, { [weak self] (episodes) in
            self?.setupEpisodes(episodes: episodes)
        }) { (error) in
            DialogManager.showErrorDialog(controller: self, title: "Ошибка от сервера", message: error)
        }
    }
    
    private func setupEpisodes(episodes: [Episode]?) {
        self.episodes = episodes
        episodesTableView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    //TODO: Перенести в окно чата, когда оно появится
    func chatFieldValidate(message: String?) -> Bool {
        return message != nil && message!.count > 0
    }
    
    func showErrorDialog(title: String?, message: String?) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (_) in
            alert.dismiss(animated: true, completion: nil)
        }))
        present(alert, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
           picker.dismiss(animated: true)
           
           guard let image = info[.editedImage] as? UIImage else {
               print("No image found")
               return
           }
           
           AlamofireSingleton().editUser(token: AlamofireSingleton.token!, avatar: image, { (users) in
               print("success")
           }) { (error) in
               DialogManager.showErrorDialog(controller: self, title: "Ошибка от сервера", message: error)
           }
       }
    

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movie?.images?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == framesCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "frameCell", for: indexPath)
            (cell.viewWithTag(2) as? UIImageView)?.kf.setImage(with: URL(string: ImageHelper.getImagePath(localPath: movie!.images![indexPath.row])));
            return cell
        }
        
        return UICollectionViewCell()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return episodes?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "episodeCell", for: indexPath) as! EpisodeTableViewCell
        cell.episodeName.text = episodes?[indexPath.row].name
        cell.episodeDescription.text = episodes?[indexPath.row].description
        cell.episodeYear.text = episodes?[indexPath.row].year
        if episodes?[indexPath.row].images != nil && episodes![indexPath.row].images.count > 0 {
            cell.episodePoster.kf.setImage(with: URL(string: ImageHelper.getImagePath(localPath: episodes![indexPath.row].images[0])));
        }
        return cell
    }
}
