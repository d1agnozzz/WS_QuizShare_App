//
//  ViewController.swift
//  WorldCinema
//
//  Created by WorldSkills MAD
//  Copyright © 2020 WS. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

  @IBOutlet weak var emailField: UITextField!
  @IBOutlet weak var passwordField: UITextField!
  @IBOutlet weak var registerButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    
  override func viewDidLoad() {
    super.viewDidLoad()
    
    [emailField, passwordField].forEach { field in
      field?.layer.cornerRadius = 4
      field?.layer.borderWidth = 1
      field?.layer.borderColor = UIColor(red: 0.66, green: 0.66, blue: 0.66, alpha: 1).cgColor
      field?.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 16, height: 44))
      field?.leftViewMode = .always
      field?.rightView = UIView(frame: CGRect(x: 0, y: 0, width: 16, height: 44))
      field?.rightViewMode = .always
    }
    
    emailField.attributedPlaceholder = NSAttributedString(string:"E-mail", attributes: [NSAttributedString.Key.foregroundColor: UIColor(red: 0.66, green: 0.66, blue: 0.66, alpha: 1)])
    passwordField.attributedPlaceholder = NSAttributedString(string:"Пароль", attributes: [NSAttributedString.Key.foregroundColor: UIColor(red: 0.66, green: 0.66, blue: 0.66, alpha: 1)])
    
    registerButton.layer.cornerRadius = 4
    registerButton.layer.borderWidth = 1
    registerButton.layer.borderColor = UIColor(red: 0.66, green: 0.66, blue: 0.66, alpha: 1).cgColor
  }
    
    
    @IBAction func onLoginButtonClick() {
        if !isMailValid {
            DialogManager.showErrorDialog(controller: self, title: "Ошибка ввода", message: "Некорректный email")
            return
        }
        if !isPasswordValid {
            DialogManager.showErrorDialog(controller: self, title: "Ошибка ввода", message: "Необходимо ввести пароль")
            return
        }
        let user = UserSignIn()
        user.email = emailField.text!
        user.password = passwordField.text!
        AlamofireSingleton().signIn(userSignIn: user, { (response)  in
            if response != nil {
                AlamofireSingleton.token = "\(response.token!)"
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: "mainViewController")
                vc.modalPresentationStyle = .fullScreen
            }
        }) { (error) in
                DialogManager.showErrorDialog(controller: self, title: "Ошибка от сервера", message: error)
        }
    }
    
    private var isMailValid: Bool {
            get {
                if emailField.text?.count != 0 {
                    return false
                }
                let regExp = "[a-z0-9]+@[a-z0-9]+.[a-z]+"
                let regex = try! NSRegularExpression(pattern: regExp)
                let range = NSRange(location: 0, length: emailField.text!.count)
                return regex.firstMatch(in: emailField.text!, options: [], range: range) == nil
            }
    }

    private var isPasswordValid: Bool {
            return passwordField.text!.count != 0
    }
    

}

