//
//  HomeViewController.swift
//  WorldCinema
//
//  Created by WorldSkills MAD
//  Copyright © 2020 WS. All rights reserved.
//

import UIKit
import Kingfisher

class MainViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    @IBOutlet weak var singoutButton: UIButton!
    @IBOutlet weak var collectionView3: UICollectionView!
    @IBOutlet weak var collectionView4: UICollectionView!
    @IBOutlet weak var collectionView5: UICollectionView!
    @IBOutlet weak var imageView3: UIImageView!
    @IBOutlet weak var imageView4: UIImageView!
    @IBOutlet weak var imageView8: UIImageView!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var lastViewName: UILabel!
    @IBOutlet weak var lastViewPoster: UIImageView!
    
    private var coverMovieId = ""
    private var lastMovieId = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        singoutButton.layer.cornerRadius = 1
        singoutButton.layer.borderWidth = 1
        singoutButton.layer.borderColor = UIColor(red: 0.66, green: 0.66, blue: 0.66, alpha: 1).cgColor
        
        collectionView3.dataSource = self
        collectionView4.dataSource = self
        collectionView5.dataSource = self
        collectionView3.delegate = self
        collectionView4.delegate = self
        collectionView5.delegate = self
        
        let s = AlamofireSingleton()
        s.getCover(token: AlamofireSingleton.token, { [weak self] (cover) in
            self?.imageView4.kf.setImage(with: URL(string: ImageHelper.getImagePath(localPath: cover?.backgroundImage)));
            self?.imageView8.kf.setImage(with: URL(string: ImageHelper.getImagePath(localPath: cover?.foregroundImage)));
            if let c = cover?.movieId {
                self?.coverMovieId = c
            }
        }) { (error) in
            DialogManager.showErrorDialog(controller: self, title: "Ошибка от сервера", message: error)
        }
        
        s.getMovies(filter: "inTrend", { [weak self] (movies) in
            self?.newMovies = movies
            self?.collectionView4.reloadData()
        }) { (error) in
            DialogManager.showErrorDialog(controller: self, title: "Ошибка от сервера", message: error)
        }
        
        s.getMovies(filter: "new", { [weak self] (movies) in
            self?.newMovies = movies
            self?.collectionView4.reloadData()
        }) { (error) in
            DialogManager.showErrorDialog(controller: self, title: "Ошибка от сервера", message: error)
        }
        
        s.getMovies(filter: "forMe", { [weak self] (movies) in
            self?.forMeMovies = movies
            self?.collectionView5.reloadData()
        }) { (error) in
            DialogManager.showErrorDialog(controller: self, title: "Ошибка от сервера", message: error)
        }
        
        s.getUser(token: AlamofireSingleton.token, { [weak self] (user) in
            if user?[0].avatarId != nil {
                self?.imageView3.kf.setImage(with: URL(string: ImageHelper.getImagePath(localPath: user?[0].avatarId)))
            }
            self?.label.text = (user?[0].firstName)! + " " + (user?[0].lastName)!
            self?.label2.text = (user?[0].email)!
        }) { (error) in
            DialogManager.showErrorDialog(controller: self, title: "Ошибка от сервера", message: error)
        }
        
        s.getUserMovies(token: AlamofireSingleton.token, filter: "lastView", {[weak self] movies in
            if (movies?.count)! > 0 {
                self?.lastViewName.text = movies?[0].name
                self?.lastViewPoster.kf.setImage(with: URL(string: ImageHelper.getImagePath(localPath: (movies?[0].poster)!)))
                self?.lastMovieId = (movies?[0].movieId)!
            }
            }, onError: {(error) in
                DialogManager.showErrorDialog(controller: self, title: "Ошибка от сервера", message: error)
        })
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    @IBAction func onChangeButtonClick() {
        let alert = UIAlertController(title: "Choose your profile picture", message: "", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Take photo", style: .default, handler: { [weak self] (action) in
            let vc = UIImagePickerController()
            vc.sourceType = .camera
            vc.allowsEditing = true
            vc.delegate = self
            self?.present(vc, animated: true)
        }))
        alert.addAction(UIAlertAction(title: "Choose from Gallery", style: .default, handler: {[weak self] (action) in
            let vc = UIImagePickerController()
            vc.sourceType = .photoLibrary
            vc.allowsEditing = true
            vc.delegate = self
            self?.present(vc, animated: true)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
        }))
        present(alert, animated: true)
    }
    
    @IBAction func onButton8Click() {
        AlamofireSingleton.token = nil
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func onLastViewClick() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "movieViewController") as! MovieViewController
        vc.modalPresentationStyle = .fullScreen
        vc.movieId = lastMovieId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    private var newMovies: [Movie]? = nil
    private var trendMovies: [Movie]? = nil
    private var forMeMovies: [Movie]? = nil
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView === collectionView3 {
            if trendMovies != nil {
                return trendMovies!.count
            }
        } else if collectionView === collectionView4 {
            if newMovies != nil {
                return newMovies!.count
            }
        } else if collectionView === collectionView5 {
            if forMeMovies != nil {
                return forMeMovies!.count
            }
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView === collectionView3 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "trendCell", for: indexPath)
            (cell.viewWithTag(2) as! UIImageView).kf.setImage(with: URL(string: ImageHelper.getImagePath(localPath: trendMovies?[indexPath.row].poster)));
            return cell
        } else if collectionView === collectionView4 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "newCell", for: indexPath)
            (cell.viewWithTag(2) as! UIImageView).kf.setImage(with: URL(string: ImageHelper.getImagePath(localPath: newMovies?[indexPath.row].poster)));
            return cell
        } else if collectionView === collectionView5 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "forYouCell", for: indexPath)
            (cell.viewWithTag(2) as! UIImageView).kf.setImage(with: URL(string: ImageHelper.getImagePath(localPath: forMeMovies?[indexPath.row].poster)));
            return cell
        }
        return UICollectionViewCell()
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        var movieId = ""
        if collectionView === collectionView3 {
            movieId = (trendMovies?[indexPath.row].movieId)!
        } else if collectionView === collectionView4 {
            movieId = (newMovies?[indexPath.row].movieId)! + "1"
        } else if collectionView === collectionView5 {
            movieId = (forMeMovies?[indexPath.row].movieId)! + "0"
        }
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "movieViewController") as! MovieViewController
        vc.movieId = movieId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        
        guard let image = info[.editedImage] as? UIImage else {
            print("No image found")
            return
        }
        
        AlamofireSingleton().editUser(token: AlamofireSingleton.token!, avatar: image, { (users) in
            print("success")
        }) { (error) in
            DialogManager.showErrorDialog(controller: self, title: "Ошибка от сервера", message: error)
        }
    }
}
