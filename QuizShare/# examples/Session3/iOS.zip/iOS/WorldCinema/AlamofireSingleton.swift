//
//  AlamofireSingleton.swift
//  WorldCinema
//
//  Copyright © 2020 WS. All rights reserved.
//

import Foundation
import Alamofire

class AlamofireSingleton {
    
    static var token: String? = ""
    
   // private let instance:
    
    func signIn(userSignIn: UserSignIn, _ onComplete: @escaping (_ signInResponse: SignInResponse) -> Void, onError:  @escaping (_ message: String) -> Void) {
        
        AF.request("http://cinema.areas.su/auth/login",
                   method: .post,
                   parameters: userSignIn,
                   encoder: JSONParameterEncoder.default).response { response in
                    switch response.result {
                    case .success(let data):
                        onComplete(try! JSONDecoder().decode(SignInResponse.self, from: data!))
                    case .failure(let error):
                        onError(error.errorDescription ?? "")
                    }
        }
    }
    
    func getMovies(filter: String?, _ onComplete: @escaping (_ movies: [Movie]?) -> Void, onError:  @escaping (_ message: String) -> Void) {
        
        AF.request("http://cinema.areas.su/movies",
                   method: .get,
                   parameters: ["filter" : filter!],
                   encoding: URLEncoding(destination: .queryString)).response { response in
                    switch response.result {
                    case .success(let data):
                        onComplete(try! JSONDecoder().decode([Movie].self, from: data!))
                    case .failure(let error):
                        onError(error.errorDescription ?? "")
                    }
        }
    }
    
    func getCover(token: String?, _ onComplete: @escaping (_ cover: Cover?) -> Void, onError:  @escaping (_ message: String) -> Void) {
        
        AF.request("http://cinema.areas.su/movies/cover",
                   method: .get,
                   headers: ["Authorization" : "Bearer \(token!)"]).response { response  in
                    switch response.result {
                    case .success(let data):
                        onComplete(try! JSONDecoder().decode(Cover.self, from: data!))
                    case .failure(let error):
                        onError(error.errorDescription ?? "")
                    }
        }
    }
    
    func getMoviesEpisodes(movieId: String, _ onComplete: @escaping (_ episodes: [Episode]?) -> Void, onError:  @escaping (_ message: String) -> Void) {
        
        AF.request("http://cinema.areas.su/movies/\(movieId)/episodes",
                   method: .get).response { response in
                    switch response.result {
                    case .success(let data):
                        onComplete(try! JSONDecoder().decode([Episode].self, from: data!))
                    case .failure(let error):
                        onError(error.errorDescription ?? "")
                    }
        }
    }
    
    func getChats(token: String?, _ onComplete: @escaping (_ chats: [Chat]?) -> Void, onError:  @escaping (_ message: String) -> Void) {
        
        AF.request("http://cinema.areas.su/user/chats",
                   method: .get,
                   headers: ["Authorization" : "Bearer \(token!)"]).response { response  in
                    switch response.result {
                    case .success(let data):
                        onComplete(try! JSONDecoder().decode([Chat].self, from: data!))
                    case .failure(let error):
                        onError(error.errorDescription ?? "")
                    }
        }
    }
    
    func getMessages(token: String?, chatId: Int, _ onComplete: @escaping (_ messages: [Message]?) -> Void, onError:  @escaping (_ message: String) -> Void) {
        
        AF.request("http://cinema.areas.su/chats/\(chatId)/messages",
                   method: .get,
                  
                   headers: ["Authorization" : "Bearer \(token!)"]).response { response  in
                    switch response.result {
                    case .success(let data):
                        onComplete(try! JSONDecoder().decode([Message].self, from: data!))
                    case .failure(let error):
                        onError(error.errorDescription ?? "")
                    }
        }
    }
    
    func sendMessage(message: MessageForm, token: String?, chatId: Int, _ onComplete: @escaping (_ messages: [Message]?) -> Void, onError:  @escaping (_ message: String) -> Void) {
        
        AF.request("http://cinema.areas.su/chats/\(chatId)/messages,
            method: .post,
            parameters: message,
            encoder: JSONParameterEncoder.default,
            headers: ["Authorization" : "Bearer \(token!)"]).response { response  in
                switch response.result {
                case .success(let data):
                    onComplete(try! JSONDecoder().decode([Message].self, from: data!))
                case .failure(let error):
                    onError(error.errorDescription ?? "")
                }
        }
    }
    
    func getUser(token: String?, _ onComplete: @escaping (_ user: [User]?) -> Void, onError:  @escaping (_ message: String) -> Void) {
        let httpHeaders: HTTPHeaders = ["Authorization" : "Bearer \(token!)",  "Accept": "application/json"]
        AF.request("http://cinema.areas.su/user",
                   method: .get,
                   headers: httpHeaders).response { response  in
                    switch response.result {
                    case .success(let data):
                        onComplete(try! JSONDecoder().decode([User].self, from: data!))
                    case .failure(let error):
                        onError(error.errorDescription ?? "")
                    }
        }
    }
    
    func getUserMovies(token: String?, filter: String?, _ onComplete: @escaping (_ movies: [Movie]?) -> Void, onError:  @escaping (_ message: String) -> Void) {
         let httpHeaders: HTTPHeaders = ["Authorization" : "Bearer \(token!)",  "Accept": "application/json"]
        AF.request("http://cinema.areas.su/usermovies",
                   method: .get,
                   parameters: ["filter" : filter!],
                   encoding: URLEncoding(destination: .queryString),
                   headers: httpHeaders).response { response in
                    switch response.result {
                    case .success(let data):
                        onComplete(try! JSONDecoder().decode([Movie].self, from: data!))
                    case .failure(let error):
                        onError(error.errorDescription ?? "")
                    }
        }
    }
    
    func getMovie(movieId: String, _ onComplete: @escaping (_ movie: Movie?) -> Void, onError:  @escaping (_ message: String) -> Void) {
        
        AF.request("http://cinema.areas.su/movies/\(movieId)",
                   method: .get).response { response in
                    switch response.result {
                    case .success(let data):
                        onComplete(try! JSONDecoder().decode(Movie.self, from: data!))
                    case .failure(let error):
                        onError(error.errorDescription ?? "")
                    }
        }
    }
    
    func editUser(token: String, avatar: UIImage, _ onComplete: @escaping (_ user: User?) -> Void, onError:  @escaping (_ message: String) -> Void) {
        
        let data = avatar.pngData()!
        var request = URLRequest(url: URL(string: "http://cinema.areas.su/user/avatar")!)
        request.httpMethod = "POST"
        
        AF.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(data, withName: "file", fileName: "avatar.jpg", mimeType: "image/png")
            multipartFormData.append(Data(token.utf8), withName: "token", mimeType: "text/plain")
        }, with:request)
            .responseJSON(completionHandler: { response in
                switch response.result {
                case .success(let data):
                    let array = data as! [Any]
                    let dict = array[0]
                    let user = try! JSONSerialization.data(withJSONObject: dict, options: .prettyPrinted)
                    onComplete(try! JSONDecoder().decode(User.self, from: user))
                case .failure(let error):
                    print(error)
                    onError(error.errorDescription ?? "")
                }
            })
    }
    
}
