package com.ws.worldcinema;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class MovieFramesAdapter extends RecyclerView.Adapter<MovieFramesAdapter.MovieFrameViewHolder> {

    private ArrayList<String> frames;

    public ArrayList<String> getFrames() {
        return frames;
    }

    public void setFrames(ArrayList<String> frames) {
        this.frames = frames;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MovieFrameViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_film_landscape, parent, false);
        return new MovieFrameViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieFrameViewHolder holder, final int posiion) {
        Glide.with(holder.itemView.getContext()).load(ImageHelper.getImagePath(frames.get(position))).into(holder.poster);
    }

    @Override
    public int getItemCount() {
        return frames.size();
    }

    class MovieFrameViewHolder extends RecyclerView.ViewHolder {

        ImageView poster;

        public MovieFrameViewHolder(View itemView) {
            super(itemView);
            poster = itemView.findViewById(R.id.poster);
        }
    }
}
