package com.ws.worldcinema;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ws.worldcinema.databinding.ActivityMainBinding;
import com.ws.worldcinema.model.Cover;
import com.ws.worldcinema.model.Movie;
import com.ws.worldcinema.model.User;

import org.jetbrains.annotations.NotNull;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    interface OnMovieClickListener {
        public void onMovieClick(Movie movie);
    }

    private ActivityMainBinding binding;
    private int coverMovieId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        ApiService service = new RetrofitSingleton().service;

        Call<Cover> call2 = service.getCover(RetrofitSingleton.getToken());
        call2.enqueue(new Callback<Cover>() {
            @Override
            public void onResponse(Call<Cover> call, Response<Cover> response) {
                Glide.with(MainActivity.this).load(ImageHelper.getImagePath(response.body().getBackgroundImage())).into(binding.include2.imageView4);
                Glide.with(MainActivity.this).load(ImageHelper.getImagePath(response.body().getForegroundImage())).into(binding.include2.imageView8);
                coverMovieId = response.body().getMovieId();
            }

            @Override
            public void onFailure(Call<Cover> call, Throwable t) {
                DialogManager.showErrorDialog(MainActivity.this, "Ошибка от сервера", t.getLocalizedMessage());
            }
        });

        binding.include3.recyclerView3.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        binding.include3.recyclerView3.setAdapter(new PortraitMovieAdapter());
        ((PortraitMovieAdapter) binding.include3.recyclerView3.getAdapter()).setOnClickListener(new OnMovieClickListener() {
            @Override
            public void onMovieClick(Movie movie) {
                Intent intent = new Intent(MainActivity.this, MovieActivity.class);
                intent.putExtra(Movie.MOVIE_ID_KEY, movie.getMovieId());
                startActivity(intent);
            }
        });
        Call<ArrayList<Movie>> call3 = service.getMovies("inTrend");
        call3.enqueue(new Callback<ArrayList<Movie>>() {
            @Override
            public void onResponse(Call<ArrayList<Movie>> call, Response<ArrayList<Movie>> response) {
                ((PortraitMovieAdapter) binding.include3.recyclerView4.getAdapter()).setMovies(response.body());
            }

            @Override
            public void onFailure(Call<ArrayList<Movie>> call, Throwable t) {
                DialogManager.showErrorDialog(MainActivity.this, "Ошибка от сервера", t.getLocalizedMessage());
            }
        });

        binding.include3.recyclerView4.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        binding.include3.recyclerView4.setAdapter(new LandscapeMovieAdapter());
        ((LandscapeMovieAdapter) binding.include3.recyclerView4.getAdapter()).setOnClickListener(new OnMovieClickListener() {
            @Override
            public void onMovieClick(Movie movie) {
                Intent intent = new Intent(MainActivity.this, MovieActivity.class);
                intent.putExtra(Movie.MOVIE_ID_KEY, movie.getMovieId()+1);
                startActivity(intent);
            }
        });
        Call<ArrayList<Movie>> call4 = service.getMovies("new");
        call4.enqueue(new Callback<ArrayList<Movie>>() {
            @Override
            public void onResponse(Call<ArrayList<Movie>> call, Response<ArrayList<Movie>> response) {
                ((LandscapeMovieAdapter) binding.include3.recyclerView4.getAdapter()).setMovies(response.body());
            }

            @Override
            public void onFailure(Call<ArrayList<Movie>> call, Throwable t) {
                DialogManager.showErrorDialog(MainActivity.this, "Ошибка от сервера", t.getLocalizedMessage());
            }
        });

        binding.include3.recyclerView5.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        binding.include3.recyclerView5.setAdapter(new PortraitMovieAdapter());
        ((PortraitMovieAdapter) binding.include3.recyclerView5.getAdapter()).setOnClickListener(new OnMovieClickListener() {
            @Override
            public void onMovieClick(Movie movie) {
                Intent intent = new Intent(MainActivity.this, MovieActivity.class);
                intent.putExtra(Movie.MOVIE_ID_KEY, movie.getMovieId()-1);
                startActivity(intent);
            }
        });
        Call<ArrayList<Movie>> call5 = service.getMovies("forMe");
        call5.enqueue(new Callback<ArrayList<Movie>>() {
            @Override
            public void onResponse(Call<ArrayList<Movie>> call, Response<ArrayList<Movie>> response) {
                ((PortraitMovieAdapter) binding.include3.recyclerView4.getAdapter()).setMovies(response.body());
            }

            @Override
            public void onFailure(Call<ArrayList<Movie>> call, Throwable t) {
                DialogManager.showErrorDialog(MainActivity.this, "Ошибка от сервера", t.getLocalizedMessage());
            }
        });

        Call<User> call6 = service.getProfile(RetrofitSingleton.getToken());
        call6.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if (response.body()!= null && response.body().getAvatarId() != null) {
                    Glide.with(MainActivity.this).load(ImageHelper.getImagePath(response.body().getAvatarId())).into(binding.include.imageView3);
                    binding.include.textView.setText(response.body().getFirstName() + " " + response.body().getLastName());
                    binding.include.textView2.setText(response.body().getEmail());
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                DialogManager.showErrorDialog(MainActivity.this, "Ошибка от сервера", t.getLocalizedMessage());
            }
        });

        binding.include.changeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Choose your profile picture");

                final CharSequence[] options = {"Take Photo", "Choose from Gallery", "Cancel"};
                builder.setItems(options, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int item) {

                        if (options[item].equals("Take Photo")) {
                            Intent takePicture = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                            startActivityForResult(takePicture, 0);

                        } else if (options[item].equals("Choose from Gallery")) {
                            Intent pickPhoto = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                            startActivityForResult(pickPhoto, 1);

                        } else if (options[item].equals("Cancel")) {
                            dialog.dismiss();
                        }
                    }
                });
                builder.show();
            }
        });

        binding.button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RetrofitSingleton.setToken(null);
                finish();
            }
        });

        Call<ArrayList<Movie>> call7 = service.getUserMovies(RetrofitSingleton.getToken(), "lastView");
        call7.enqueue(new Callback<ArrayList<Movie>>() {
            @Override
            public void onResponse(Call<ArrayList<Movie>> call, Response<ArrayList<Movie>> response) {
                if (response.body()!= null && response.body().size() > 0) {
                    binding.include.lastViewName.setText(response.body().get(0).getName());
                    Glide.with(MainActivity.this).load(ImageHelper.getImagePath(response.body().get(0).getPoster())).into(binding.include.lastViewPoster);
                    binding.include.lastViewPoster.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent intent = new Intent(MainActivity.this, MovieActivity.class);
                            intent.putExtra(Movie.MOVIE_ID_KEY, response.body().get(0).getMovieId());
                            startActivity(intent);
                        }
                    });
                }
            }

            @Override
            public void onFailure(Call<ArrayList<Movie>> call, Throwable t) {
                DialogManager.showErrorDialog(MainActivity.this, "Ошибка от сервера", t.getLocalizedMessage());
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_CANCELED) {
            switch (requestCode) {
                case 0:
                    if (resultCode == RESULT_OK && data != null) {
                        Bitmap selectedImage = (Bitmap) data.getExtras().get("data");
                        try {
                            sendAvatar(selectedImage);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    break;
                case 1:
                    Uri pickedImage = data.getData();
                    Bitmap bitmap = null;
                    try {
                        bitmap = MediaStore.Images.Media.getBitmap(
                                this.getContentResolver(), pickedImage);

                    } catch (Exception e) {
                    }

                    try {
                        sendAvatar(bitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
            }
        }
    }

    private void sendAvatar(Bitmap bitmap) throws IOException {
        ApiService service = new RetrofitSingleton().service;

        File f = new File(getCacheDir(), "avatar");
        f.createNewFile();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 0 /*ignored for PNG*/, bos);
        byte[] bitmapdata = bos.toByteArray();

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(f);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            fos.write(bitmapdata);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Map<String, RequestBody> map = new HashMap<>();
        map.put("token", RequestBody.create(MediaType.parse("text/plain"), RetrofitSingleton.getTokenWithoutBarrier()));

        RequestBody fileBody = RequestBody.create(MediaType.parse("image/png"), f);
        map.put("file\"; filename=\"avatar.png\"", fileBody);

        Call<ArrayList<User>> call = service.editUser(map);
        call.enqueue(new Callback<ArrayList<User>>() {
            @Override
            public void onResponse(Call<ArrayList<User>> call,
                                   Response<ArrayList<User>> response) {
                Log.v("Upload", "success");
            }

            @Override
            public void onFailure(Call<ArrayList<User>> call, Throwable t) {
                DialogManager.showErrorDialog(MainActivity.this, "Ошибка от сервера", t.getLocalizedMessage());
            }
        });

    }

    public class PortraitMovieAdapter extends RecyclerView.Adapter<PortraitMovieAdapter.PortraitMovieViewHolder> {

        private ArrayList<Movie> movies = new ArrayList<>();
        private OnMovieClickListener onClickListener;

        public ArrayList<Movie> getMovies() {
            return movies;
        }

        public void setMovies(ArrayList<Movie> movies) {
            this.movies = movies;
        }

        public void setOnClickListener(OnMovieClickListener onClickListener) {
            this.onClickListener = onClickListener;
        }

        @NonNull
        @Override
        public PortraitMovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_film, parent, false);
            return new PortraitMovieViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull PortraitMovieViewHolder holder, final int position) {
            Glide.with(MainActivity.this).load(ImageHelper.getImagePath(movies.get(position).getPoster())).into(holder.poster);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (onClickListener != null)
                        onClickListener.onMovieClick(movies.get(position));
                }
            });
        }

        @Override
        public int getItemCount() {
            return movies.size();
        }

        class PortraitMovieViewHolder extends RecyclerView.ViewHolder {

            private ImageView poster;

            public PortraitMovieViewHolder(View itemView) {
                super(itemView);
                poster = itemView.findViewById(R.id.poster);
            }
        }
    }

    public class LandscapeMovieAdapter extends RecyclerView.Adapter<LandscapeMovieAdapter.LandscapeMovieViewHolder> {

        private ArrayList<Movie> movies = new ArrayList<>();
        private OnMovieClickListener onClickListener;

        public ArrayList<Movie> getMovies() {
            return movies;
        }

        public void setMovies(ArrayList<Movie> movies) {
            this.movies = movies;
            notifyDataSetChanged();
        }

        public void setOnClickListener(OnMovieClickListener onClickListener) {
            this.onClickListener = onClickListener;
        }

        @NonNull
        @Override
        public LandscapeMovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_film_landscape, parent, false);
            return new LandscapeMovieViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull LandscapeMovieViewHolder holder, final int position) {
            Glide.with(MainActivity.this).load(ImageHelper.getImagePath(movies.get(position).getPoster())).into(holder.poster);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (onClickListener != null)
                        onClickListener.onMovieClick(movies.get(position));
                }
            });
        }

        @Override
        public int getItemCount() {
            return movies.size();
        }

        class LandscapeMovieViewHolder extends RecyclerView.ViewHolder {

            private ImageView poster;

            public LandscapeMovieViewHolder(View itemView) {
                super(itemView);
                poster = itemView.findViewById(R.id.poster);
            }
        }
    }
}