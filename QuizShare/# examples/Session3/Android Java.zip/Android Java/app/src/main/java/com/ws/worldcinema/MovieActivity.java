package com.ws.worldcinema;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ContextThemeWrapper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ws.worldcinema.databinding.ActivityMovieBinding;
import com.ws.worldcinema.model.Episode;
import com.ws.worldcinema.model.Movie;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MovieActivity extends AppCompatActivity {

    private ActivityMovieBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMovieBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        int movieId = getIntent().getIntExtra(Movie.MOVIE_ID_KEY, 0);
        if (movieId == 0) {
            DialogManager.showErrorDialog(this, "Ошибка", "Фильм не найден");
        } else {
            requestMovie(movieId);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void requestMovie(int movieId) {
        ApiService service = new RetrofitSingleton().service;

        Call<Movie> movieCall = service.getMovie(movieId, RetrofitSingleton.getToken());
        movieCall.enqueue(new Callback<Movie>() {
            @Override
            public void onResponse(Call<Movie> call, Response<Movie> response) {
                setupScreen(response.body());
                requestEpisodes(response.body().getMovieId());
            }

            @Override
            public void onFailure(Call<Movie> call, Throwable t) {
                DialogManager.showErrorDialog(MovieActivity.this, "Ошибка от сервера", t.getLocalizedMessage());
            }
        });
    }

    private void setupScreen(Movie movie) {
        setTitle(movie.getName());

        binding.movieDescriptionTextView.setText(movie.getDescription());

        binding.ageTextView.setText(movie.getAge());
        binding.ageTextView.setTextColor(movie.getAgeColor());
        binding.imagesRecyclerView.setAdapter(new MovieFramesAdapter());
        binding.imagesRecyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        ((MovieFramesAdapter)binding.imagesRecyclerView.getAdapter()).setFrames(movie.getImages());

        Glide.with(this).load(ImageHelper.getImagePath(movie.getPoster())).into(binding.posterImageView);
    }

    private void requestEpisodes(int movieId) {
        ApiService service = new RetrofitSingleton().service;
        Call<ArrayList<Episode>> call = service.getMovieEpisodes(movieId);
        call.enqueue(new Callback<ArrayList<Episode>>() {
            @Override
            public void onResponse(Call<ArrayList<Episode>> call, Response<ArrayList<Episode>> response) {
                setupEpisodes(response.body());
            }

            @Override
            public void onFailure(Call<ArrayList<Episode>> call, Throwable t) {
                DialogManager.showErrorDialog(MovieActivity.this, "Ошибка от сервера", t.getLocalizedMessage());
            }
        });
    }

    private void setupEpisodes(ArrayList<Episode> episodes) {
        binding.episodesRecyclerView.setAdapter(new EpisodesAdapter());
        binding.episodesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        ((EpisodesAdapter)binding.episodesRecyclerView.getAdapter()).setEpisodes(episodes);
    }

    //TODO: Перенести в окно чата, когда оно появится
    boolean chatFieldValidate(String message) {
        if (message != null && message.length() > 0)
            return true;
        return false;
    }

    void showErrorDialog(String title, String message) {
        new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.DarkDialogStyle))
                .setTitle(title)
                .setMessage(message)
                .setCancelable(true)
                .setPositiveButton("Ok", (dialog, which) -> {
                }).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_CANCELED) {
            switch (requestCode) {
                case 0
                    if (resultCode == RESULT_OK && data != null) {
                        Bitmap selectedImage = (Bitmap) data.getExtras().get("data");
                    }

                    break;
                case 1:
                    if (resultCode == RESULT_OK && data != null) {
                        Uri selectedImage = data.getData();
                        String[] filePathColumn = {MediaStore.Images.Media.DATA};
                        if (selectedImage != null) {
                            Cursor cursor = getContentResolver().query(selectedImage,
                                    filePathColumn, null, null, null);
                            if (cursor != null) {
                                cursor.moveToFirst();

                                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                                String picturePath = cursor.getString(columnIndex);
                                cursor.close();
                            }
                        }

                    }
                    break;
            }
        }
    }



}