package com.ws.worldcinema;

import android.app.AlertDialog;
import android.content.Context;

import androidx.appcompat.view.ContextThemeWrapper;

public class DialogManager {
    public static void showErrorDialog(Context context, String title, String message) {
        new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.DarkDialogStyle))
                .setTitle(title)
                .setMessage(message)
                .setCancelable(true)
                .setPositiveButton("Ok", (dialog, which) -> {
                }).show();
    }
}
