package com.ws.worldcinema;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ws.worldcinema.model.Episode;

import java.util.ArrayList;

public class EpisodesAdapter extends RecyclerView.Adapter<EpisodesAdapter.EpisodeViewHolder> {

    private ArrayList<Episode> episodes;

    public ArrayList<Episode> getEpisodes() {
        return episodes;
    }

    public void setEpisodes(ArrayList<Episode> episodes) {
        this.episodes = episodes;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public EpisodeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_episode, parent, false);
        return new EpisodeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EpisodeViewHolder holder, final int position) {
        if (episodes.get(position).getImages()!= null && episodes.get(position).getImages().size() > 0)
            Glide.with(holder.itemView.getContext()).load(ImageHelper.getImagePath(episodes.get(position).getImages().get(0))).into(holder.poster);
        holder.title.setText(episodes.get(position).getName());
        holder.description.setText(episodes.get(position).getDescription());
        holder.year.setText(episodes.get(position).getYear());
    }

    @Override
    public int getItemCount() {
        if (episodes != null) return episodes.size();
        return 0;
    }

    class EpisodeViewHolder extends RecyclerView.ViewHolder {

        ImageView poster;
        TextView title;
        TextView description;
        TextView year;

        public EpisodeViewHolder(View itemView) {
            super(itemView);
            poster = itemView.findViewById(R.id.episodePoster);
            title = itemView.findViewById(R.id.episodeName);
            description = itemView.findViewById(R.id.episodeDescription);
            year = itemView.findViewById(R.id.episodeYear);
        }
    }
}
