package com.ws.worldcinema;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class DateHelper {

    //TODO: пригодится для реализации чата
    public static String getDateForChat(String dateString) {

        try {
            Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dateString);
            Date today = new Date();
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            cal1.setTime(date);
            cal2.setTime(today);
            boolean sameDay = cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR) &&
                    cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR);
            if (sameDay)
                return "Сегодня";
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return dateString;
    }

}
