package com.ws.worldcinema;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitSingleton {

    private static String token;

    private Retrofit instance;

    ApiService service;

    public static String getToken() {
        return "Bearer " + token;
    }

    public static String getTokenWithoutBarrier() {
        return token;
    }

    public static void setToken(String token) {
        RetrofitSingleton.token = token;
    }

    RetrofitSingleton() {

        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
// set your desired log level
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
// add your other interceptors …

// add logging as last interceptor
        httpClient.addInterceptor(logging);  // <-- this is the important line!

        instance = new Retrofit.Builder()
                .baseUrl("http://cinema.areas.su/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(httpClient.build())
                .build();
        service = instance.create(ApiService.class);
    }
}
