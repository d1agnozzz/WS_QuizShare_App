package com.ws.worldcinema.model;

import android.graphics.Color;

import java.util.ArrayList;

public class Movie {

    public static final String MOVIE_ID_KEY = "movie_id_key";

    int movieId;
    String name;
    String description;
    String age;
    ArrayList<String> images;
    String poster;

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAge() {
        return age + "+";
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public void setImages(ArrayList<String> images) {
        this.images = images;
    }

    public ArrayList<String> getImages() {
        return images;
    }


    public int getAgeColor() {
        switch (age) {
            case "0": {
                return Color.WHITE;
            }
            case "6": {
                return Color.parseColor("#FAD5C9");
            }
            case "12": {
                return Color.parseColor("#F4A992");
            }
            case "16": {
                return Color.parseColor("#F26E45");
            }
            case "18": {
                return Color.parseColor("#EF3A01");
            }
        }
        return Color.WHITE;
    }
}
