package com.ws.worldcinema;

public class ImageHelper {

    public static String getImagePath(String localPath) {
        return "http://cinema.areas.su/up/images/+localPath;
    }
}
