package com.ws.worldcinema.model;

public class Message {
    private int messageId;
    private String creationDateTime;
    private String authorName;
    private String authorAvatarId;
    private String text;

    public int getMessageId() {
        return messageId;
    }

    public void setMessageId(int messageId) {
        this.messageId = messageId;
    }

    public String getCreationDateTime() {
        return creationDateTime;
    }

    public void setCreationDateTime(String creationDateTime) {
        this.creationDateTime = creationDateTime;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public String getAuthorAvatarId() {
        return authorAvatarId;
    }

    public void setAuthorAvatarId(String authorAvatarId) {
        this.authorAvatarId = authorAvatarId;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
