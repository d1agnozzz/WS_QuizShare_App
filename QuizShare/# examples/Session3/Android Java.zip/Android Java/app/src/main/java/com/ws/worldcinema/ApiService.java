package com.ws.worldcinema;

import com.ws.worldcinema.model.Chat;
import com.ws.worldcinema.model.Cover;
import com.ws.worldcinema.model.Episode;
import com.ws.worldcinema.model.Message;
import com.ws.worldcinema.model.MessageForm;
import com.ws.worldcinema.model.Movie;
import com.ws.worldcinema.model.SignInResponse;
import com.ws.worldcinema.model.User;
import com.ws.worldcinema.model.UserSignIn;

import java.util.ArrayList;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {
    @POST("auth/login")
    Call<SignInResponse> signIn(@Body UserSignIn userSignIn);

    @GET("movies/cover")
    Call<Cover> getCover(@Header("Authorization") String authHeader);

    @GET("movies")
    Call<ArrayList<Movie>> getMovies(@Query("filter") String filter);

    @GET("movies/{movieId}/episodes")
    Call<ArrayList<Episode>> getMovieEpisodes(@Path("movieId") int movieId);

    @GET("user/chats")
    Call<ArrayList<Chat>> getChats(@Header("Authorization") String authHeader);

    @GET("chats/{chatId}/messages")
    Call<ArrayList<Message>> getMessages(@Path("chatId") int chatId, @Header("Authorization") String authHeader);

    @POST("chats/{chatId}/messages)
    Call<ArrayList<Message>> sendMessage(@Body MessageForm messageForm, @Path("chatId") int chatId, @Header("Authorization") String authHeader);

    @GET("user")
    Call<User> getProfile(@Header("Authorization") String authHeader) ;

    @GET("usermovies")
    Call<ArrayList<Movie>> getUserMovies(@Header("Authorization") String authHeader, @Query("filter") String filter);

    @Multipart
    @POST("user/avatar")
   Call<ArrayList<User>> editUser(@PartMap Map<String, RequestBody> map);

    @GET("movies/{movieId}")
    Call<Movie> getMovie(@Path("movieId") int movieId, @Header("Authorization") String authHeader);
}
