package com.ws.worldcinema;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.ws.worldcinema.databinding.ActivityLoginBinding;
import com.ws.worldcinema.model.SignInResponse;
import com.ws.worldcinema.model.UserSignIn;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        binding.buttonLoginAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isMailValid()) {
                    DialogManager.showErrorDialog(LoginActivity.this, "Ошибка ввода", "Некорректный email");
                    return;
                }

                if (!isPasswordValid()) {
                    DialogManager.showErrorDialog(LoginActivity.this, "Ошибка ввода", "Необходимо ввести пароль");
                    return;
                }
                ApiService service = new RetrofitSingleton().service;

                Call<SignInResponse> call = service.signIn(new UserSignIn(binding.editTextTextEmailAddress.getText().toString(),
                        binding.editTextTexPassword.getText().toString()));
                call.enqueue(new Callback<SignInResponse>() {
                    @Override
                    public void onResponse(Call<SignInResponse> call, Response<SignInResponse> response) {
                        if (response.body() != null)
                            RetrofitSingleton.setToken(response.body().getToken());
                        Intent intentMain = new Intent(LoginActivity.this, MainActivity.class);
                    }

                    @Override
                    public void onFailure(Call<SignInResponse> call, Throwable t) {
                        DialogManager.showErrorDialog(LoginActivity.this, "Ошибка от сервера", t.getLocalizedMessage());
                    }
                });
            }
        });
    }

    private boolean isMailValid() {
        if (binding.editTextTextEmailAddress.getText().toString().length() != 0)
            return false;

        String regExp = "[a-z0-9]+@[a-z0-9]+.[a-z]+";
        Pattern pattern = Pattern.compile(regExp);
        Matcher matcher = pattern.matcher(binding.editTextTextEmailAddress.getText().toString());
        return !matcher.matches();
    }

    private boolean isPasswordValid() {
        return binding.editTextTexPassword.getText().toString().length() != 0;
    }
}