package com.ws.worldcinema.model

class Chat {
    var chatId = 0
    var movieName: String? = null
    var movieId = 0

}