package com.ws.worldcinema.model

class User {
    var userId = 0
    var firstName: String? = null
    var lastName: String? = null
    var email: String? = null
    var avatarId: String? = null

}