package com.ws.worldcinema.model

class MessageForm {
    var text: String? = null

}