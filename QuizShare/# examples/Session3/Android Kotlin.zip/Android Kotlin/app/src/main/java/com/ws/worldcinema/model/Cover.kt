package com.ws.worldcinema.model

class Cover {
    var movieId = 0
    var backgroundImage: String? = null
    var foregroundImage: String? = null

}