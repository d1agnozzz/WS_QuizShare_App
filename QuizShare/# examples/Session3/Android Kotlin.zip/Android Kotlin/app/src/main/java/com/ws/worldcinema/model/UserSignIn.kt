package com.ws.worldcinema.model

class UserSignIn(var email: String, var password: String)