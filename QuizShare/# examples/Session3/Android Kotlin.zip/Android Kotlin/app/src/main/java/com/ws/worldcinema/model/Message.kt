package com.ws.worldcinema.model

class Message {
    var messageId = 0
    var creationDateTime: String? = null
    var authorName: String? = null
    var authorAvatarId: String? = null
    var text: String? = null

}