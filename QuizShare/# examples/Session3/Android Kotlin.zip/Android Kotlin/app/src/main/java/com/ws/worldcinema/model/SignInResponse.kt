package com.ws.worldcinema.model

class SignInResponse {
    var token: String? = null

}